<?php

namespace App\Http\Controllers;

use App\Models\Cita;
use App\Models\Mascota;
use Illuminate\Http\Request;
use App\Models\User;

class CitaController extends Controller
{
    public function index()
    {
        $citas = Cita::where('user_id', auth()->id())->get();
        return view('citas.index', compact('citas'));
    }

    public function create()
    {
        $mascotas = Mascota::where('dni_dueño', auth()->user()->dni)->get();
        return view('citas.create', compact('mascotas'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'mascota_id' => 'required',
            'fecha' => 'required|date',
            'hora' => 'required',
            'motivo' => 'required|string'
        ]);

        Cita::create([
            'mascota_id' => $request->mascota_id,
            'user_id' => auth()->id(),
            'fecha' => $request->fecha,
            'hora' => $request->hora,
            'motivo' => $request->motivo,
        ]);

        return redirect()->route('citas.index');
    }
}
