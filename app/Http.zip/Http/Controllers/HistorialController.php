<?php

namespace App\Http\Controllers;

use App\Models\Historial;
use App\Models\Mascota;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;

class HistorialController extends Controller
{
    public function create()
    {
        $mascotas = Mascota::all();
        return view('historiales.create', compact('mascotas'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'mascota_id' => 'required',
            'tipo' => 'required',
            'descripcion' => 'required',
        ]);

        $historial = Historial::create([
            'mascota_id' => $request->mascota_id,
            'tipo' => $request->tipo,
            'descripcion' => $request->descripcion,
            'fecha' => now(),
        ]);

        $pdf = Pdf::loadView('historiales.pdf', compact('historial'));
        $filename = 'historial_' . $historial->id . '.pdf';
        $path = storage_path('app/public/historiales/' . $filename);
        $pdf->save($path);

        $historial->update(['archivo_pdf' => $filename]);

        return redirect()->route('historiales.index');
    }
}
