<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Mascota;

class MascotaController extends Controller
{
    public function index()
    {
        return Mascota::all(); // Devuelve todas las mascotas
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:255',
            'edad' => 'required|integer|min:0',
            'tipo' => 'required|string|max:255',
            'dueño_id' => 'required|exists:users,id',
        ]);

        return Mascota::create($validated);
    }

    public function show($id)
    {
        return Mascota::findOrFail($id);
    }

    public function update(Request $request, $id)
    {
        $mascota = Mascota::findOrFail($id);
        $mascota->update($request->all());

        return $mascota;
    }

    public function destroy($id)
    {
        Mascota::findOrFail($id)->delete();
        return response()->json(['mensaje' => 'Mascota eliminada'], 200);
    }
}
