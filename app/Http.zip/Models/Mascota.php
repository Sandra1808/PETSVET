<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mascota extends Model
{
    use HasFactory;

    protected $fillable = [
        'nombre',
        'microchip',
        'dueño_id', // Cambié 'dni_dueño' por 'dueño_id' para usar la referencia correcta
        'fecha_nacimiento',
        'sexo',
    ];

    public function dueño()
    {
        return $this->belongsTo(User::class, 'dueño_id');
    }
}
