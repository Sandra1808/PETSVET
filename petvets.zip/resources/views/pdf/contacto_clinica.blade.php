<div style="font-size:12px; color:#444; margin-top:30px; border-top:1px solid #ccc; padding-top:8px;">
    <b>Dirección:</b> Calle Ejemplo, Nº 0, Ciudad Ficticia &nbsp; | &nbsp;
    <b>Teléfono:</b> 999 999 999 &nbsp; | &nbsp;
    <b>Email:</b> contacto@petsvet.fake &nbsp; | &nbsp;
    <b>Horario:</b> L-V 00:00-00:00, S 00:00-00:00, D Cerrado &nbsp; | &nbsp;
    <b>Instagram:</b> @petsvet_falso &nbsp; <b>Facebook:</b> Pet's Vet Fake &nbsp; <b>Twitter/X:</b> @PetsVet_000
</div> 