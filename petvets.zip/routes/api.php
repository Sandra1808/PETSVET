<?php

// Archivo de rutas API vacío para evitar errores. 